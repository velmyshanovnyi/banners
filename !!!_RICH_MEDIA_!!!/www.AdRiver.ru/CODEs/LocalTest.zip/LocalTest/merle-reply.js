(function(ph){
try {
var a = adriver(ph);
a.reply = {
ph: ph,
rnd:'123',
bt:52,
sid:0,
pz:0,
sz:'',
bn:0,
sliceid:0,
netid:0,
ntype:0, 
tns:0,
adid:0,
bid:0,
cgihref:'http://www.ru/?',
target: '_blank', 
width:'',
height:'',
alt:'Adriver',
mirror:''
}
a.reply.comppath = a.reply.mirror;
adriver.loadScript(a.reply.comppath + 'script.js' + '?v' + ph)
}catch(e){}}(ar_ph));