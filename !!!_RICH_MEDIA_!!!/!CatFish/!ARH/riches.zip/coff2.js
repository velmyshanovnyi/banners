document.write('<span style="position: absolute; left: 0; top: 3; width: 728; height: 600; z-index: 1">');

document.write('<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="728" HEIGHT="600" id="leader-4" ALIGN="">');

document.write('<PARAM NAME=movie VALUE="http://to-dress.ru/imedia/leader/leader-coff2.swf"><PARAM NAME=quality VALUE=high><PARAM NAME=wmode VALUE=transparent><PARAM NAME=bgcolor VALUE=#FFFFFF>');

document.write('<EMBED src="http://to-dress.ru/imedia/leader/leader-coff2.swf" quality=high wmode=transparent bgcolor=#FFFFFF WIDTH="728" HEIGHT="600" NAME="leader-coff2" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED></OBJECT></span>');