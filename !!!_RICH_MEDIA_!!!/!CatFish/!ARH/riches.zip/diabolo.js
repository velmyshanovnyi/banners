document.write('<span style="position: absolute; left: 390; top: 250; width: 600; height: 90; z-index: 1">');

document.write('<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="600" HEIGHT="90" id="diabolo-burgua-1" ALIGN="">');

document.write('<PARAM NAME=movie VALUE="http://to-dress.ru/imedia/diabolo/diabolo-burgua-1.swf"><PARAM NAME=quality VALUE=high><PARAM NAME=wmode VALUE=transparent><PARAM NAME=bgcolor VALUE=#FFFFFF>');

document.write('<EMBED src="http://to-dress.ru/imedia/diabolo/diabolo-burgua-1.swf" quality=high wmode=transparent bgcolor=#FFFFFF WIDTH="600" HEIGHT="90" NAME="diabolo-burgua-1" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED></OBJECT></span>');