document.write('<span style="position: absolute; left: 18; top: 3; width: 800; height: 600; z-index: 1">');

document.write('<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,0,0" WIDTH="800" HEIGHT="600" id="rich-crave-min" ALIGN="">');

document.write('<PARAM NAME=movie VALUE="rich-crave-min.swf"><PARAM NAME=quality VALUE=high><PARAM NAME=wmode VALUE=transparent><PARAM NAME=bgcolor VALUE=#FFFFFF>');

document.write('<EMBED src="rich-crave-min.swf" quality=high wmode=transparent bgcolor=#FFFFFF WIDTH="800" HEIGHT="600" NAME="rich-crave-min" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED></OBJECT></span>');