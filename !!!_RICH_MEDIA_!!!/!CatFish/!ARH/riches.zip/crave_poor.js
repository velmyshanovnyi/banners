document.write('<span style="position: absolute; left: 618; top: 3; width: 120; height: 90; z-index: 1">');
document.write('<img border="0" src="klein-poor.gif" width="120" height="90"></span>');
